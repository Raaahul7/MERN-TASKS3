import React from 'react';
import UserTable from './UserTable';
function App() {
  return (
    <div style={{textAlign:"center"}}>
      <UserTable />
    </div>
  );
}
export default App;